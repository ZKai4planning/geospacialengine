import { localProjector, pointInRing, ringEdgeDistance, openRing } from '../utils/geomLite.js';
import { logger } from '../utils/logger.js';

/**
 * Is this point inside a coal mining Development High Risk Area (Mining Remediation Authority, formerly the Coal Authority)?
 *
 * Answers { status: 'inside' | 'near' | 'outside' | 'unavailable', distanceM, name, source, reason }.
 * "outside" only ever means "not inside a mapped high-risk area" - the point can still be in the coalfield's low-risk area, and this is
 * NOT a Mining Report. When no data is loaded the answer is 'unavailable', never 'outside'.
 *
 * Sources, in order:  1. your own Postgres table `coal_risk_areas` (npm run import:coal)   2. optional live ArcGIS layer (COAL_LIVE_URL).
 * LICENCE: the data's licence is not clear (data.gov.uk lists OGL, the dataset's own metadata says "Coal Authority data licence").
 * That is why this provider is OFF unless COAL_RISK_ENABLED=true. Confirm re-use terms with the Mining Remediation Authority first.
 *
 * `db` is a pg-style pool: db.query(sql, params) -> { rows }.
 */
export function createCoalRisk({ db = null, liveUrl = null, fetchJson = null, nearM = 250 } = {}) {
  let warned = false;
  const warnOnce = (msg, extra) => { if (!warned) { warned = true; logger.warn(extra ?? {}, msg); } };

  async function local({ lat, lng }) {
    const meta = await db.query("select features, source, loaded_at from coal_risk_meta where kind = 'high'", []);
    if (!meta.rows?.length || !(Number(meta.rows[0].features) > 0)) return null;                       // nothing loaded
    const dLat = nearM / 111320, dLng = dLat / Math.cos((lat * Math.PI) / 180);
    const { rows } = await db.query(
      "select ref, name, parts from coal_risk_areas where kind = 'high' and bbox && box(point($1, $2), point($3, $4))",
      [lng + dLng, lat + dLat, lng - dLng, lat - dLat],
    );
    const proj = localProjector(lat, lng), origin = [0, 0];
    let best = null;
    for (const row of rows) {
      const parts = typeof row.parts === 'string' ? JSON.parse(row.parts) : row.parts;
      for (const poly of parts) {
        const outer = openRing(poly[0].map(proj)), holes = poly.slice(1).map((h) => openRing(h.map(proj)));
        const inside = pointInRing(origin, outer) && !holes.some((h) => pointInRing(origin, h));
        const d = inside ? 0 : Math.min(ringEdgeDistance(origin, outer), ...holes.map((h) => ringEdgeDistance(origin, h)));
        if (!best || d < best.d) best = { d, name: row.name ?? null, ref: row.ref ?? null };
      }
    }
    const loaded = meta.rows[0].loaded_at ? new Date(meta.rows[0].loaded_at).toISOString().slice(0, 10) : null;
    const source = `Mining Remediation Authority, Development High Risk Area${loaded ? ` (loaded ${loaded})` : ''}`;
    if (best && best.d === 0) return { status: 'inside', distanceM: 0, name: best.name, source };
    if (best && best.d <= nearM) return { status: 'near', distanceM: Math.round(best.d), name: best.name, source };
    return { status: 'outside', distanceM: null, name: null, source };
  }

  async function live({ lat, lng }) {
    const q = new URLSearchParams({ f: 'json', geometry: `${lng},${lat}`, geometryType: 'esriGeometryPoint', inSR: '4326', spatialRel: 'esriSpatialRelIntersects', returnGeometry: 'false', outFields: '*', where: '1=1' });
    const data = await fetchJson(`${liveUrl.replace(/\/$/, '')}/query?${q}`, { timeoutMs: 12000 });
    if (data?.error || !Array.isArray(data?.features)) return null;
    const f = data.features[0];
    const source = 'Mining Remediation Authority, Development High Risk Area (live service)';
    return f ? { status: 'inside', distanceM: 0, name: f.attributes?.CLASS_NAME ?? f.attributes?.ADVICETYPE ?? null, source } : { status: 'outside', distanceM: null, name: null, source };
  }

  return {
    name: 'coal-dhra',
    async check({ lat, lng }) {
      if (lat == null || lng == null) return { status: 'unavailable', reason: 'No location.' };
      if (db) {
        try { const r = await local({ lat, lng }); if (r) return r; }
        catch (e) { warnOnce('coal risk table lookup failed (run db/schema-coal.sql and npm run import:coal)', { err: e.message }); }
      }
      if (liveUrl && fetchJson) {
        try { const r = await live({ lat, lng }); if (r) return r; }
        catch (e) { warnOnce('coal risk live lookup failed', { err: e.message }); }
      }
      return { status: 'unavailable', reason: db || liveUrl ? 'Coal mining data is not loaded or could not be read.' : 'Coal mining data is not set up.' };
    },
  };
}
