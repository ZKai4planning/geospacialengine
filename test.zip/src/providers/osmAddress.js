import { fetchJson } from '../utils/http.js';
import { overpass } from './overpass.js';
import { config } from '../config.js';
import { classifyOsm } from './classification.js';
import { haversine } from '../utils/geo.js';
import { logger } from '../utils/logger.js';

const PHOTON = 'https://photon.komoot.io/api/';
const UK_BBOX = '-8.7,49.8,1.8,60.9';
const NOMINATIM = 'https://nominatim.openstreetmap.org/lookup';
const NOMINATIM_SEARCH = 'https://nominatim.openstreetmap.org/search';
const PREFIX = { node: 'N', way: 'W', relation: 'R' };

/** One OSM object by id from Nominatim (a single small request that keeps working while the public Overpass servers are down). */
async function nominatimById(type, id) {
  const u = new URL(NOMINATIM);
  u.searchParams.set('osm_ids', `${PREFIX[type]}${id}`);
  u.searchParams.set('format', 'jsonv2');
  u.searchParams.set('addressdetails', '1');
  u.searchParams.set('extratags', '1');
  const rows = await fetchJson(u.toString(), { timeoutMs: 8000, retries: 0 });
  const r = Array.isArray(rows) ? rows[0] : null;
  if (!r) return null;
  const a = r.address ?? {};
  if (!a.house_number && !a.house_name) return null;          // not an addressable building: let Overpass have a go
  const category = r.category ?? r.class;
  return fromTags({
    osmType: type, osmId: id,
    tags: {
      'addr:housenumber': a.house_number, 'addr:housename': a.house_name, 'addr:street': a.road ?? a.pedestrian ?? a.footway,
      'addr:postcode': a.postcode, 'addr:city': a.city || a.town || a.village || a.suburb || a.hamlet,
      building: category === 'building' ? r.type : r.extratags?.building,
    },
    lat: Number(r.lat), lng: Number(r.lon),
  });
}

function fromTags({ osmType, osmId, tags, lat, lng, postcodeFallback = null }) {
  const num = tags['addr:housenumber'];
  const name = tags['addr:housename'];
  const street = tags['addr:street'];
  const town = tags['addr:city'] || tags['addr:town'] || tags['addr:village'] || tags['addr:suburb'] || null;
  const postcode = (tags['addr:postcode'] || postcodeFallback || '').toUpperCase();
  const line1 = [num, street].filter(Boolean).join(' ');
  return {
    id: `osm:${osmType}:${osmId}`,
    uprn: null, // OSM has no UPRN – see README for how to enrich later
    fullAddress: [name, line1, town, postcode].filter(Boolean).join(', '),
    organisation: null, subBuilding: tags['addr:unit'] || null, buildingName: name || null,
    buildingNumber: num || null, thoroughfare: street || null, dependentLocality: null,
    postTown: town, postcode, lat, lng, easting: null, northing: null, localCustodian: null,
    classification: classifyOsm(tags.building, tags),
  };
}

const typeName = { N: 'node', W: 'way', R: 'relation', node: 'node', way: 'way', relation: 'relation' };
async function photonFind(query, limit) {
  const u = new URL(PHOTON);
  u.searchParams.set('q', query);
  u.searchParams.set('limit', String(limit + 5));
  u.searchParams.set('lang', 'en');
  u.searchParams.set('bbox', UK_BBOX);
  const data = await fetchJson(u.toString(), { timeoutMs: 10000, retries: 0 });
  return (data?.features ?? [])
    .filter((f) => f.properties?.countrycode === 'GB' && f.properties.housenumber)
    .map((f) => {
      const p = f.properties;
      return fromTags({
        osmType: typeName[p.osm_type] ?? 'node', osmId: p.osm_id,
        tags: {
          'addr:housenumber': p.housenumber, 'addr:street': p.street, 'addr:postcode': p.postcode,
          'addr:city': p.city || p.district || p.locality,
        },
        lat: f.geometry.coordinates[1], lng: f.geometry.coordinates[0],
      });
    })
    .slice(0, limit);
}

/** Free-text search via Nominatim (fallback for Photon). */
async function nominatimFind(query, limit) {
  const u = new URL(NOMINATIM_SEARCH);
  u.searchParams.set('q', query);
  u.searchParams.set('countrycodes', 'gb');
  u.searchParams.set('format', 'jsonv2');
  u.searchParams.set('addressdetails', '1');
  u.searchParams.set('limit', String(Math.min(limit + 10, 40)));
  const rows = await fetchJson(u.toString(), { timeoutMs: 10000, retries: 0 });
  return (Array.isArray(rows) ? rows : [])
    .filter((r) => r.address?.house_number || r.address?.house_name)
    .map((r) => {
      const a = r.address;
      return fromTags({
        osmType: typeName[r.osm_type] ?? 'node', osmId: r.osm_id,
        tags: {
          'addr:housenumber': a.house_number, 'addr:housename': a.house_name, 'addr:street': a.road ?? a.pedestrian ?? a.footway,
          'addr:postcode': a.postcode, 'addr:city': a.city || a.town || a.village || a.suburb || a.hamlet,
        },
        lat: Number(r.lat), lng: Number(r.lon),
      });
    })
    .slice(0, limit);
}

const centre = (el) => ({ lat: el.lat ?? el.center?.lat, lng: el.lon ?? el.center?.lon });

/**
 * Keyless address provider built on OpenStreetMap.
 *  - free-text type-ahead: Photon (komoot) geocoder
 *  - addresses at a postcode: Overpass API; one address by id: Nominatim, then Overpass
 * Coverage of addr:* tags in OSM is good in most towns but incomplete – treat it as "best effort" and let
 * the applicant add a missing address manually.
 */
export function createOsmAddress({ postcodes }) {
  return {
    name: 'osm',

    /**
     * Addresses at a postcode. A country-wide tag search is far too heavy for the public Overpass servers, so we
     * look up the postcode's coordinates (postcodes.io) and search a small circle around it:
     *  1. addresses whose addr:postcode matches                      -> exact
     *  2. addresses with NO addr:postcode tag within ~100 m          -> inferred (OSM often omits the tag)
     */
    async byPostcode(postcode, { limit = 250 } = {}) {
      const info = await postcodes.lookup(postcode);
      if (!info) return [];
      const R = config.overpassRadiusM;
      const q = `[out:json][timeout:15];(nwr(around:${R},${info.lat},${info.lng})["addr:housenumber"];nwr(around:${R},${info.lat},${info.lng})["addr:housename"];);out tags center ${limit};`;
      const data = await overpass(q);
      const want = postcode.replace(/\s+/g, '').toUpperCase();
      const seen = new Map();
      for (const el of data?.elements ?? []) {
        const c = centre(el);
        if (c.lat == null || !el.tags) continue;
        const tagged = (el.tags['addr:postcode'] || '').replace(/\s+/g, '').toUpperCase();
        const exact = tagged === want;
        const inferred = !tagged && haversine(c, info) <= 100;
        if (!exact && !inferred) continue;
        const a = fromTags({ osmType: el.type, osmId: el.id, tags: el.tags, ...c, postcodeFallback: postcode });
        const key = a.fullAddress.toLowerCase();
        if (!seen.has(key) || el.type === 'way') seen.set(key, a); // prefer the building polygon over a bare node
      }
      return [...seen.values()];
    },

    async find(query, { limit = 10 } = {}) {
      // Photon first; if it errors or finds nothing, fall back to Nominatim (a different host, so one outage does not take both down).
      let photonErr;
      try {
        const out = await photonFind(query, limit);
        if (out.length) return out;
      } catch (e) { photonErr = e; logger.warn({ err: e.message }, 'photon failed, trying nominatim'); }
      try { return await nominatimFind(query, limit); }
      catch (e) { if (photonErr) throw photonErr; throw e; }
    },

    async byId(id) {
      const m = /^osm:(node|way|relation):(\d+)$/.exec(id);
      if (!m) return null;
      try { const a = await nominatimById(m[1], m[2]); if (a) return a; }
      catch (e) { logger.warn({ err: e.message, id }, 'nominatim lookup failed, trying overpass'); }
      const data = await overpass(`[out:json][timeout:10];${m[1]}(${m[2]});out tags center;`, { timeoutMs: 8000, hedgeMs: 3000 });
      const el = data?.elements?.[0];
      if (!el) return null;
      return fromTags({ osmType: el.type, osmId: el.id, tags: el.tags ?? {}, ...centre(el) });
    },
  };
}
