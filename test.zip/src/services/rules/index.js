import { neighbourRule } from './neighbours.js';
import { boundaryRule } from './boundary.js';
import { roadRule } from './roads.js';
import { publicLandRule } from './publicLand.js';
import { streetRule } from './streetFeatures.js';
import { regulatoryRule } from './regulatory.js';
import { areaRule } from './areas.js';
import { fortyFiveRule } from './fortyFive.js';
import { tpoZoneRule } from './tpoZones.js';
import { treeRule } from './trees.js';
import { customRules } from './custom.js';
import { logger } from '../../utils/logger.js';

/** Rules run in this order, so messages appear neighbours -> boundary -> roads -> public land -> street features -> tree zones -> trees -> yours. */
export const SITE_RULES = [neighbourRule, boundaryRule, roadRule, publicLandRule, streetRule, areaRule, tpoZoneRule, treeRule, fortyFiveRule, regulatoryRule, ...customRules];

/** Adds a rule at runtime. Returns a function that removes it again (handy in tests). */
export function registerRule(rule) {
  if (typeof rule?.run !== 'function' || !rule.id) throw new TypeError('A rule needs an id and a run(ctx, result) function.');
  SITE_RULES.push(rule);
  return () => { const i = SITE_RULES.indexOf(rule); if (i >= 0) SITE_RULES.splice(i, 1); };
}

export function runRules(ctx, result, rules = SITE_RULES) {
  for (const rule of rules) {
    try { rule.run(ctx, result); }
    catch (e) {
      logger.warn({ rule: rule.id, err: e.message }, 'site rule failed');
      result.items.push({ status: 'info', message: `The "${rule.id}" check could not be completed.` });
    }
  }
}
